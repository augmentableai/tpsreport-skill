# KB Metadata Enrichment — Skills Package

Distribution bundle for the **KB Lifecycle Manager** skill used with TPSReport + Obsidian + Cursor (or any agent with Python).

## What's in the package

| File | Role |
|------|------|
| `SKILL.md` | **Required.** Agent instructions — lifecycle phases, metadata rules, quality bar |
| `metadata-contract.yaml` | **Required for linting.** Machine-readable key contract (must stay in sync with plugin Gatekeeper) |
| `kb_lint.py` | **Required for Phase 4 validation.** Run on a vault folder; exit 0 = lint-clean |

The YAML file is **not** optional if you use `kb_lint.py` — the linter reads `metadata-contract.yaml` from the same directory as the script.

## Install — Cursor (project skill)

1. Unzip or copy this folder into your repo:

   ```text
   .cursor/skills/kb-metadata-enrichment/
   ├── SKILL.md
   ├── metadata-contract.yaml
   └── kb_lint.py
   ```

2. Cursor discovers skills from `.cursor/skills/*/SKILL.md` automatically.

3. Optional: copy `backend/test-vault/_KB_Agent_Prompt_Template.md` from the TPSReport monorepo for a copy-paste KB authoring prompt.

## Install — Cursor (personal skill)

Same layout under:

```text
%USERPROFILE%\.cursor\skills\kb-metadata-enrichment\
```

Use when you build KBs across multiple projects.

## Validate a KB folder

```bash
python .cursor/skills/kb-metadata-enrichment/kb_lint.py path/to/your/KB_folder/
```

Requires **Python 3.9+** and **PyYAML** (`pip install pyyaml`).

## What users need beyond this package

| Requirement | Purpose |
|-------------|---------|
| **Obsidian** (desktop) | Write and map vault folders |
| **[TPSReport plugin](https://github.com/augmentableai/tpsreport-obsidian-sync)** | Publish, push, pull, Gatekeeper |
| **TPSReport account** + `obs_…` API key | Cloud sync ([tpsreport.pro](https://tpsreport.pro)) |
| **Cursor** (or agent + shell) | Run skill + `kb_lint.py` during authoring |
| **Python 3 + PyYAML** | Local lint only (plugin Gatekeeper runs in Obsidian without Python) |

This package does **not** include the plugin or backend — only KB authoring workflow + lint tooling.

## Version

Bundled from monorepo skill path `.cursor/skills/kb-metadata-enrichment/` — keep in sync when the plugin `RAG_FM_KEYS` change.

## License

Same as parent TPSReport / Augmentable LLC project (MIT unless otherwise noted in repo root).
